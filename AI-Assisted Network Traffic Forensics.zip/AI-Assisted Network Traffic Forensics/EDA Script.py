import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

df = pd.read_csv("suricata_flows.csv", low_memory=False)

plt.figure(figsize=(10, 5))
sns.countplot(x="proto", data=df, order=df['proto'].value_counts().index)
plt.title("Distribution of Protocols")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

top_src_ips = df['src_ip'].value_counts().head(10)
plt.figure(figsize=(10, 5))
sns.barplot(x=top_src_ips.index, y=top_src_ips.values)
plt.title("Top 10 Source IPs")
plt.xticks(rotation=45)
plt.ylabel("Count")
plt.tight_layout()
plt.show()

top_dest_ips = df['dest_ip'].value_counts().head(10)
plt.figure(figsize=(10, 5))
sns.barplot(x=top_dest_ips.index, y=top_dest_ips.values)
plt.title("Top 10 Destination IPs")
plt.xticks(rotation=45)
plt.ylabel("Count")
plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 5))
sns.countplot(x="flow_state", data=df, order=df['flow_state'].value_counts().index)
plt.title("Distribution of Flow States")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')

df.set_index('timestamp', inplace=True)
df['proto'].resample('1Min').count().plot(figsize=(12, 5))
plt.title("Flow Count per Minute")
plt.ylabel("Number of Flows")
plt.tight_layout()
plt.show()
plt.show(block=True)
