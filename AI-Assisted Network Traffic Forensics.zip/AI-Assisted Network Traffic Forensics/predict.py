
import pandas as pd
import joblib
import sys

def predict_traffic(csv_file):
    # Load model and scaler
    model = joblib.load("models/rf_model.joblib")
    scaler = joblib.load("models/scaler.joblib")
    
    # Load data
    df = pd.read_csv(csv_file)
    
    # Get the same features used during training
    feature_cols = ['bytes_toclient', 'bytes_toserver', 'pkts_toclient', 'pkts_toserver', 'src_port', 'dest_port', 'tcp_syn', 'tcp_ack', 'tcp_rst']
    
    # Filter to only include available features
    available_features = [col for col in feature_cols if col in df.columns]
    
    if not available_features:
        raise ValueError("None of the required features are in the dataset")
    
    # Prepare features
    X = df[available_features]
    
    # Scale features
    X_scaled = scaler.transform(X)
    
    # Make predictions
    predictions = model.predict(X_scaled)
    
    # Add predictions to dataframe
    df['prediction'] = predictions
    
    # Save results
    output_file = csv_file.replace('.csv', '_predictions.csv')
    df.to_csv(output_file, index=False)
    print(f"Predictions saved to {output_file}")
    
    # Count predictions
    prediction_counts = df['prediction'].value_counts()
    print("\nPrediction counts:")
    for label, count in prediction_counts.items():
        print(f"{label}: {count}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python predict.py <csv_file>")
        sys.exit(1)
    
    predict_traffic(sys.argv[1])
