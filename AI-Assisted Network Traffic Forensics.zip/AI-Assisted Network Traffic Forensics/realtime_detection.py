import os
import sys
import time
import json
import pandas as pd
import joblib
import argparse
import logging
from datetime import datetime
import subprocess
import threading
import signal
from sklearn.preprocessing import StandardScaler

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ids_detection.log"),
        logging.StreamHandler(sys.stdout)
    ]
)

class NetworkTrafficMonitor:
    def __init__(self, model_path="models/rf_model.joblib", scaler_path="models/scaler.joblib", 
                 interface=None, threshold=0.8, interval=60):
        """
        Initialize the Network Traffic Monitor
        
        Args:
            model_path: Path to the trained model
            scaler_path: Path to the feature scaler
            interface: Network interface to monitor (e.g., eth0)
            threshold: Probability threshold for anomaly detection
            interval: Interval (in seconds) for processing captured traffic
        """
        self.interface = interface
        self.threshold = threshold
        self.interval = interval
        self.stop_flag = False
        
        # Load model and scaler
        try:
            self.model = joblib.load(model_path)
            self.scaler = joblib.load(scaler_path)
            logging.info("Model and scaler loaded successfully")
        except Exception as e:
            logging.error(f"Failed to load model or scaler: {e}")
            sys.exit(1)
            
        # Determine features used for model - fixed to handle GridSearchCV wrapper
        # Default set of features used in training
        self.feature_names = [
            'bytes_toclient', 'bytes_toserver', 
            'pkts_toclient', 'pkts_toserver',
            'src_port', 'dest_port', 
            'tcp_syn', 'tcp_ack', 'tcp_rst'
        ]
        
        # Try to get feature names from the model if available
        try:
            if hasattr(self.model, 'best_estimator_'):
                if hasattr(self.model.best_estimator_, 'feature_names_in_'):
                    self.feature_names = self.model.best_estimator_.feature_names_in_
            elif hasattr(self.model, 'feature_names_in_'):
                self.feature_names = self.model.feature_names_in_
        except Exception as e:
            logging.warning(f"Could not extract feature names from model: {e}")
            logging.info("Using default feature set")
        
        logging.info(f"Using features: {self.feature_names}")
        
        # Create directory for outputs
        os.makedirs("alerts", exist_ok=True)
        
    def start_suricata(self):
        """Start Suricata IDS to capture network traffic"""
        if not self.interface:
            logging.error("No network interface specified")
            return False
        
        cmd = [
            "suricata", 
            "-c", "/etc/suricata/suricata.yaml",  # Adjust path as needed
            "-i", self.interface,
            "--set", "outputs.eve-log.filename=eve.json"
        ]
        
        try:
            logging.info(f"Starting Suricata on interface {self.interface}")
            self.suricata_process = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            return True
        except Exception as e:
            logging.error(f"Failed to start Suricata: {e}")
            return False
            
    def process_traffic(self):
        """Process captured traffic data and detect anomalies"""
        try:
            # Read the Suricata eve.json log file
            if os.path.exists("eve.json"):
                # Read the JSON log line by line (it's not a valid JSON file as a whole)
                flows = []
                with open("eve.json", "r") as f:
                    for line in f:
                        try:
                            event = json.loads(line)
                            if event.get("event_type") == "flow":
                                flows.append({
                                    'timestamp': event.get("timestamp"),
                                    'src_ip': event.get("src_ip"),
                                    'src_port': event.get("src_port"),
                                    'dest_ip': event.get("dest_ip"),
                                    'dest_port': event.get("dest_port"),
                                    'proto': event.get("proto"),
                                    'pkts_toserver': event.get("flow", {}).get("pkts_toserver"),
                                    'pkts_toclient': event.get("flow", {}).get("pkts_toclient"),
                                    'bytes_toserver': event.get("flow", {}).get("bytes_toserver"),
                                    'bytes_toclient': event.get("flow", {}).get("bytes_toclient"),
                                    'tcp_syn': 1 if "S" in event.get("tcp_flags", "") else 0,
                                    'tcp_ack': 1 if "A" in event.get("tcp_flags", "") else 0,
                                    'tcp_rst': 1 if "R" in event.get("tcp_flags", "") else 0,
                                })
                        except json.JSONDecodeError:
                            continue
                
                if not flows:
                    logging.info("No flows found in the log file")
                    return
                    
                # Convert to DataFrame
                df = pd.DataFrame(flows)
                logging.info(f"Loaded {len(df)} flows from Suricata logs")
                
                # Extract features for prediction
                available_features = [col for col in self.feature_names if col in df.columns]
                if not available_features:
                    logging.error("None of the required features are in the captured data")
                    return
                    
                X = df[available_features].fillna(0)
                
                # Scale features
                X_scaled = self.scaler.transform(X)
                
                # Make predictions
                df['prediction'] = self.model.predict(X_scaled)
                if hasattr(self.model, 'predict_proba'):
                    try:
                        probas = self.model.predict_proba(X_scaled)
                        if probas.shape[1] >= 2:  # Binary classification
                            df['malicious_probability'] = probas[:, 1]
                    except Exception as e:
                        logging.warning(f"Could not calculate prediction probabilities: {e}")
                
                # Get suspicious traffic (based on model prediction or threshold)
                suspicious = df[df['prediction'] == 1]  # Assuming 1 is malicious
                if 'malicious_probability' in df.columns:
                    high_prob = df[df['malicious_probability'] > self.threshold]
                    suspicious = pd.concat([suspicious, high_prob]).drop_duplicates()
                
                # Log alerts for suspicious traffic
                if not suspicious.empty:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    alert_file = f"alerts/suspicious_traffic_{timestamp}.csv"
                    suspicious.to_csv(alert_file, index=False)
                    
                    logging.warning(f"Found {len(suspicious)} suspicious connections!")
                    for  row in suspicious.head(10).iterrows():  # Show max 10 alerts
                        logging.warning(
                            f"ALERT: {row.get('src_ip')}:{row.get('src_port')} -> "
                            f"{row.get('dest_ip')}:{row.get('dest_port')} "
                            f"(Proto: {row.get('proto')})"
                        )
                    if len(suspicious) > 10:
                        logging.warning(f"... and {len(suspicious) - 10} more. See {alert_file}")
                    
                    # Optionally trigger external alert system
                    # self.trigger_alert(suspicious)
                else:
                    logging.info("No suspicious traffic detected in this batch")
                
                # Save all traffic with predictions for later analysis
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                df.to_csv(f"traffic_analysis_{timestamp}.csv", index=False)
            else:
                logging.warning("Suricata log file (eve.json) not found")
                
        except Exception as e:
            logging.error(f"Error processing traffic data: {e}")
    
    def continuous_monitoring(self):
        """Continuously monitor network traffic at specified intervals"""
        logging.info(f"Starting continuous monitoring at {self.interval} second intervals")
        
        while not self.stop_flag:
            self.process_traffic()
            time.sleep(self.interval)
    
    def start(self):
        """Start the monitoring process"""
        if self.interface:
            if not self.start_suricata():
                return
        
        # Start monitoring in a separate thread
        self.monitor_thread = threading.Thread(target=self.continuous_monitoring)
        self.monitor_thread.start()
        
        logging.info("Network traffic monitoring started")
        
        # Wait for Ctrl+C to stop
        try:
            while self.monitor_thread.is_alive():
                time.sleep(1)
        except KeyboardInterrupt:
            logging.info("Stopping monitoring (Ctrl+C received)")
            self.stop()
    
    def stop(self):
        """Stop the monitoring process"""
        self.stop_flag = True
        
        # Stop Suricata if it was started
        if hasattr(self, 'suricata_process'):
            self.suricata_process.terminate()
            
        logging.info("Network traffic monitoring stopped")

def simulate_traffic(output_file="simulated_eve.json", num_records=100, include_malicious=True):
    """
    Simulate network traffic for testing when actual network monitoring is not possible
    
    Args:
        output_file: Output file to write simulated traffic
        num_records: Number of records to generate
        include_malicious: Whether to include malicious traffic patterns
    """
    import random
    import ipaddress
    
    logging.info(f"Generating {num_records} simulated traffic records")
    
    # Generate random IPs
    def random_ip():
        return str(ipaddress.IPv4Address(random.randint(0, 2**32 - 1)))
    
    # Common ports
    common_ports = [80, 443, 22, 3389, 8080, 25, 53]
    
    with open(output_file, "w") as f:
        for i in range(num_records):
            # Decide if this will be a malicious record (10% chance if enabled)
            is_malicious = include_malicious and random.random() < 0.1
            
            # Generate basic flow data
            record = {
                "timestamp": datetime.now().isoformat(),
                "event_type": "flow",
                "src_ip": random_ip(),
                "dest_ip": random_ip(),
                "proto": random.choice(["TCP", "UDP", "ICMP"]),
                "flow": {
                    "pkts_toserver": random.randint(1, 1000),
                    "pkts_toclient": random.randint(1, 1000),
                    "bytes_toserver": random.randint(40, 10000),
                    "bytes_toclient": random.randint(40, 10000),
                }
            }
            
            # Set ports based on protocol
            if record["proto"] != "ICMP":
                if is_malicious:
                    # Unusual port for potential port scanning
                    record["src_port"] = random.randint(1024, 65535)
                    record["dest_port"] = random.randint(1, 65535)
                else:
                    # Common client ports and server ports
                    record["src_port"] = random.randint(49152, 65535)
                    record["dest_port"] = random.choice(common_ports)
            
            # Add TCP flags if it's TCP
            if record["proto"] == "TCP":
                flags = []
                # SYN packet
                if random.random() < 0.3:
                    flags.append("S")
                # ACK packet
                if random.random() < 0.7:
                    flags.append("A")
                # RST packet (more likely in malicious traffic)
                if is_malicious and random.random() < 0.4:
                    flags.append("R")
                elif random.random() < 0.05:
                    flags.append("R")
                    
                record["tcp_flags"] = "".join(flags)
            
            # Add malicious characteristics
            if is_malicious:
                # Simulate scanning or unusual traffic patterns
                if random.random() < 0.5:
                    # Port scanning: Many packets but small size
                    record["flow"]["pkts_toserver"] = random.randint(50, 200)
                    record["flow"]["bytes_toserver"] = record["flow"]["pkts_toserver"] * random.randint(40, 60)
                else:
                    # Data exfiltration: Few packets but large size
                    record["flow"]["pkts_toserver"] = random.randint(1, 10)
                    record["flow"]["bytes_toserver"] = random.randint(100000, 1000000)
            
            # Write as JSON line
            f.write(json.dumps(record) + "\n")
    
    logging.info(f"Simulated traffic written to {output_file}")
    return output_file

def main():
    parser = argparse.ArgumentParser(description="AI-Assisted Network Traffic Monitor for Intrusion Detection")
    parser.add_argument("--interface", "-i", help="Network interface to monitor")
    parser.add_argument("--model", default="models/rf_model.joblib", help="Path to trained model")
    parser.add_argument("--scaler", default="models/scaler.joblib", help="Path to feature scaler")
    parser.add_argument("--interval", type=int, default=60, help="Processing interval in seconds")
    parser.add_argument("--threshold", type=float, default=0.8, help="Probability threshold for alerts")
    parser.add_argument("--simulate", action="store_true", help="Simulate traffic for testing")
    args = parser.parse_args()
    
    if args.simulate:
        eve_file = simulate_traffic()
        logging.info("Using simulated traffic instead of live capture")
    elif not args.interface:
        logging.error("No network interface specified. Use --interface or --simulate")
        parser.print_help()
        return

    # Create and start the monitor
    monitor = NetworkTrafficMonitor(
        model_path=args.model,
        scaler_path=args.scaler,
        interface=args.interface,
        threshold=args.threshold,
        interval=args.interval
    )
    
    monitor.start()

if __name__ == "__main__":
    main() 