# Network Traffic ML GUI

This GUI application provides a complete interface for the AI-Assisted Network Traffic Forensics ML system. It allows you to load network traffic data, train machine learning models, make predictions, and visualize results.

## Features

- **Upload Data**: Load network traffic data from CSV files or use pre-existing sample data
- **Train Models**: Configure and train Random Forest models with custom parameters
- **Make Predictions**: Use trained models to detect malicious network traffic
- **View Results**: Visualize prediction results with charts and detailed analysis

## Requirements

```
streamlit
pandas
numpy
matplotlib
seaborn
scikit-learn
joblib
```

## Installation

Install the required packages:

```bash
pip install streamlit pandas numpy matplotlib seaborn scikit-learn joblib
```

## Usage

1. Start the Streamlit app:

```bash
streamlit run ml_gui.py
```

2. Navigate through the application using the sidebar:

    - **Upload Data**: Upload your network traffic CSV file or use sample data
    - **Train Model**: Configure and train a Random Forest model
    - **Make Predictions**: Predict malicious traffic on new data
    - **View Results**: Explore detailed visualizations of prediction results

## Data Format

The application expects CSV files with network traffic data. It requires the following columns for predictions:

- `bytes_toclient` 
- `bytes_toserver`
- `pkts_toclient`
- `pkts_toserver`
- `src_port`
- `dest_port`
- `tcp_syn` (optional)
- `tcp_ack` (optional)
- `tcp_rst` (optional)

For training, it additionally requires a `label` column with traffic classifications.

## Screenshots

- The "Upload Data" page allows you to load network traffic CSV files
- The "Train Model" page lets you configure model hyperparameters and evaluate performance
- The "Make Predictions" page identifies malicious traffic in new data
- The "View Results" page provides comprehensive visualizations and analysis

## Workflow

1. Upload your network traffic data
2. Train a model or load a pre-existing one
3. Make predictions on new traffic data
4. Analyze the results with visualizations
5. Download prediction results as CSV

## Project Structure

- `ml_gui.py`: Main application file
- `models/`: Directory containing saved models
- `*.csv`: Input and output CSV data files 