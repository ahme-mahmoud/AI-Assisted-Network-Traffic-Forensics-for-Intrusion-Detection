import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="AI-Assisted Network Traffic Forensics", layout="wide")
st.title("Network Traffic Dashboard")

file = st.sidebar.file_uploader("Upload your network log (CSV)", type="csv")

tab1, tab2, tab3 = st.tabs(["Overview", "Traffic Analysis", "Threat Intelligence"])

if file:
    df = pd.read_csv(file)

    if 'timestamp' in df.columns:
        df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce')
        df['hour'] = df['timestamp'].dt.hour

    if 'protocol' in df.columns:
        selected_protocols = st.sidebar.multiselect("Filter by Protocol", options=df['protocol'].unique(), default=df['protocol'].unique())
        df = df[df['protocol'].isin(selected_protocols)]

    if 'label' in df.columns:
        selected_labels = st.sidebar.multiselect("Filter by Label", options=df['label'].unique(), default=df['label'].unique())
        df = df[df['label'].isin(selected_labels)]

    if 'hour' in df.columns:
        min_hour, max_hour = df['hour'].min(), df['hour'].max()
        if min_hour != max_hour:
            selected_hours = st.sidebar.slider("Filter by Hour", min_value=int(min_hour), max_value=int(max_hour), value=(int(min_hour), int(max_hour)))
            df = df[(df['hour'] >= selected_hours[0]) & (df['hour'] <= selected_hours[1])]
        else:
            st.sidebar.info(f"All traffic is at hour: {min_hour}")

    with tab1:
        st.subheader("Key Metrics")

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Total Connections", len(df))

        with col2:
            malicious_count = df[df['label'].str.lower() == 'malicious'].shape[0] if 'label' in df.columns else 0
            st.metric("Malicious Connections", malicious_count)

        with col3:
            unique_ips = df['src_ip'].nunique() if 'src_ip' in df.columns else 0
            st.metric("Unique Source IPs", unique_ips)

        with col4:
            unique_intents = df['intent'].nunique() if 'intent' in df.columns else 0
            st.metric("Detected Intents", unique_intents)

        st.subheader("Data Preview")
        st.dataframe(df.head())

        st.subheader("Suspicious IPs")
        suspicious_ips = df[df['label'].str.contains('malicious', case=False, na=False)]['src_ip'].unique()
        for ip in suspicious_ips:
            st.error(f"Suspicious IP Detected: {ip}")

    with tab2:
        st.subheader("Protocol Distribution")
        if 'protocol' in df.columns:
            fig, ax = plt.subplots()
            sns.countplot(data=df, x='protocol', order=df['protocol'].value_counts().index, ax=ax)
            st.pyplot(fig)

        st.subheader(" Top Source IPs")
        if 'src_ip' in df.columns:
            top_sources = df['src_ip'].value_counts().head(10)
            st.bar_chart(top_sources)

        st.subheader("Traffic Over Time")
        if 'hour' in df.columns:
            hourly = df['hour'].value_counts().sort_index()
            st.line_chart(hourly)

    with tab3:
        for col in ['label', 'intent', 'operator']:
            if col in df.columns:
                st.subheader(f" {col.capitalize()} Distribution")
                fig, ax = plt.subplots()
                sns.countplot(data=df, x=col, order=df[col].value_counts().index, ax=ax)
                plt.xticks(rotation=45)
                st.pyplot(fig)

else:
    st.warning(" Please upload a CSV file to continue.")
