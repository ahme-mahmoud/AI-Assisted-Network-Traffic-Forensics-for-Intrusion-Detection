import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import os
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import io
import base64

# Page config
st.set_page_config(page_title="Network Traffic ML Analysis", layout="wide")

# Function to download data
def get_download_link(df, filename, text):
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="{filename}">{text}</a>'
    return href

# Function to load model and scaler
def load_model():
    try:
        model = joblib.load("models/rf_model.joblib")
        scaler = joblib.load("models/scaler.joblib")
        return model, scaler
    except:
        st.error("Model or scaler not found. Please train a model first.")
        return None, None

# Function to make predictions
def predict_traffic(df, model, scaler):
    feature_cols = ['bytes_toclient', 'bytes_toserver', 'pkts_toclient', 'pkts_toserver', 
                  'src_port', 'dest_port', 'tcp_syn', 'tcp_ack', 'tcp_rst']
    
    available_features = [col for col in feature_cols if col in df.columns]
    
    if not available_features:
        st.error("None of the required features are in the dataset")
        return None
    
    # Prepare features
    X = df[available_features]
    
    # Scale features
    X_scaled = scaler.transform(X)
    
    # Make predictions
    predictions = model.predict(X_scaled)
    
    # Add predictions to dataframe
    df['prediction'] = predictions
    
    return df

# Function to train model
def train_model(df, target_column, test_size=0.2, n_estimators=100, max_depth=None, min_samples_split=2):
    # Select features
    feature_columns = [
        'bytes_toclient', 'bytes_toserver', 
        'pkts_toclient', 'pkts_toserver',
        'src_port', 'dest_port',
        'tcp_syn', 'tcp_ack', 'tcp_rst'
    ]
    
    # Filter to only include columns that exist in the dataset
    available_features = [col for col in feature_columns if col in df.columns]
    
    if not available_features:
        st.error(f"None of the specified feature columns exist in the dataset")
        return None, None, None, None
    
    if target_column not in df.columns:
        st.error(f"Target column '{target_column}' not found in dataset")
        return None, None, None, None
    
    # Handle missing values
    df = df.dropna(subset=available_features + [target_column])
    
    # Prepare features and target
    X = df[available_features]
    y = df[target_column]
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=42)
    
    # Scale numerical features
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Train model
    model = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        min_samples_split=min_samples_split,
        random_state=42
    )
    
    model.fit(X_train_scaled, y_train)
    
    return model, scaler, X_test_scaled, y_test

# Title
st.title("🧠 Network Traffic ML Analysis")

# Sidebar
st.sidebar.title("Options")
page = st.sidebar.radio("Navigation", ["Upload Data", "Train Model", "Make Predictions", "View Results"])

# Initialize session state for data storage
if 'data' not in st.session_state:
    st.session_state.data = None
if 'model' not in st.session_state:
    st.session_state.model = None
if 'scaler' not in st.session_state:
    st.session_state.scaler = None
if 'predictions' not in st.session_state:
    st.session_state.predictions = None
if 'test_results' not in st.session_state:
    st.session_state.test_results = None

# Upload Data page
if page == "Upload Data":
    st.header("📤 Upload Network Traffic Data")
    
    upload_option = st.radio("Select upload method:", ["Upload CSV file", "Use sample data"])
    
    if upload_option == "Upload CSV file":
        uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
        if uploaded_file:
            data = pd.read_csv(uploaded_file)
            st.session_state.data = data
            st.success(f"Data loaded successfully! {data.shape[0]} rows and {data.shape[1]} columns.")
            st.subheader("Data Preview")
            st.dataframe(data.head())
            
            st.subheader("Data Information")
            buffer = io.StringIO()
            data.info(buf=buffer)
            st.text(buffer.getvalue())
    
    elif upload_option == "Use sample data":
        sample_data = st.selectbox("Select sample data:", ["suricata_flows_with_label.csv", "suricata_flows.csv"])
        if st.button("Load Sample Data"):
            try:
                data = pd.read_csv(sample_data)
                st.session_state.data = data
                st.success(f"Sample data loaded successfully! {data.shape[0]} rows and {data.shape[1]} columns.")
                st.subheader("Data Preview")
                st.dataframe(data.head())
            except:
                st.error(f"Could not load sample file {sample_data}")

# Train Model page
elif page == "Train Model":
    st.header("🔍 Train ML Model")
    
    if st.session_state.data is None:
        st.warning("Please upload data first in the 'Upload Data' section.")
    else:
        st.subheader("Dataset Information")
        st.write(f"Your dataset has {st.session_state.data.shape[0]} rows and {st.session_state.data.shape[1]} columns.")
        
        if 'label' in st.session_state.data.columns:
            default_target = 'label'
        else:
            default_target = st.session_state.data.columns[0]
        
        target_options = st.session_state.data.columns.tolist()
        target_column = st.selectbox("Select target column for prediction:", 
                                    options=target_options,
                                    index=target_options.index(default_target) if default_target in target_options else 0)
        
        if not pd.api.types.is_numeric_dtype(st.session_state.data[target_column]):
            st.info(f"Target column '{target_column}' contains non-numeric values. This is OK for classification tasks.")
        
        st.write("Configure model training parameters:")
        
        col1, col2 = st.columns(2)
        with col1:
            test_size = st.slider("Test Size", 0.1, 0.5, 0.2, 0.05)
            n_estimators = st.slider("Number of Trees", 50, 500, 100, 50)
        
        with col2:
            max_depth_option = st.radio("Max Depth", ["None", "Custom"])
            max_depth = None if max_depth_option == "None" else st.slider("Custom Max Depth", 5, 50, 20)
            min_samples_split = st.slider("Min Samples Split", 2, 20, 2)
        
        if st.button("Train Model"):
            with st.spinner("Training model... This may take a while."):
                model, scaler, X_test_scaled, y_test = train_model(
                    st.session_state.data,
                    target_column=target_column,
                    test_size=test_size,
                    n_estimators=n_estimators,
                    max_depth=max_depth,
                    min_samples_split=min_samples_split
                )
                
                if model is not None:
                    st.session_state.model = model
                    st.session_state.scaler = scaler
                    
                    y_pred = model.predict(X_test_scaled)
                    accuracy = accuracy_score(y_test, y_pred)
                    
                    st.session_state.test_results = {
                        'y_test': y_test,
                        'y_pred': y_pred,
                        'accuracy': accuracy
                    }
                    
                    st.success(f"Model trained successfully! Accuracy: {accuracy:.4f}")
                    
                    # Save model
                    os.makedirs('models', exist_ok=True)
                    joblib.dump(model, "models/rf_model.joblib")
                    joblib.dump(scaler, "models/scaler.joblib")
                    
                    # Save target column name
                    with open("models/target_column.txt", "w") as f:
                        f.write(target_column)
                    
                    st.success("Model and scaler saved to disk.")
        
        if st.session_state.model is not None and st.session_state.test_results is not None:
            st.subheader("Model Evaluation")
            
            y_test = st.session_state.test_results['y_test']
            y_pred = st.session_state.test_results['y_pred']
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("Classification Report:")
                report = classification_report(y_test, y_pred, output_dict=True)
                report_df = pd.DataFrame(report).transpose()
                st.dataframe(report_df)
            
            with col2:
                st.write("Confusion Matrix:")
                fig, ax = plt.subplots(figsize=(8, 6))
                cm = confusion_matrix(y_test, y_pred)
                sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax)
                ax.set_xlabel('Predicted')
                ax.set_ylabel('Actual')
                ax.set_title('Confusion Matrix')
                st.pyplot(fig)
            
            # Feature importance
            if hasattr(st.session_state.model, 'feature_importances_'):
                feature_columns = [
                    'bytes_toclient', 'bytes_toserver', 
                    'pkts_toclient', 'pkts_toserver',
                    'src_port', 'dest_port',
                    'tcp_syn', 'tcp_ack', 'tcp_rst'
                ]
                
                available_features = [col for col in feature_columns if col in st.session_state.data.columns]
                
                feature_importance = st.session_state.model.feature_importances_
                importance_df = pd.DataFrame({
                    'Feature': available_features,
                    'Importance': feature_importance
                }).sort_values('Importance', ascending=False)
                
                st.write("Feature Importance:")
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.barplot(x='Importance', y='Feature', data=importance_df, ax=ax)
                ax.set_title('Feature Importance')
                st.pyplot(fig)

elif page == "Make Predictions":
    st.header("🔮 Make Predictions")
    
    if st.session_state.model is None or st.session_state.scaler is None:
        model_exists = os.path.exists("models/rf_model.joblib") and os.path.exists("models/scaler.joblib")
        
        if model_exists:
            if st.button("Load Saved Model"):
                model, scaler = load_model()
                if model is not None:
                    st.session_state.model = model
                    st.session_state.scaler = scaler
                    st.success("Model loaded successfully!")
        else:
            st.warning("No model found. Please train a model first.")
    
    if st.session_state.model is not None and st.session_state.scaler is not None:
        st.write("Upload data for prediction or use the data already loaded:")
        
        prediction_option = st.radio("Select data for prediction:", ["Use loaded data", "Upload new data"])
        
        prediction_data = None
        
        if prediction_option == "Use loaded data":
            if st.session_state.data is not None:
                prediction_data = st.session_state.data
                st.write("Using loaded data for prediction.")
            else:
                st.warning("No data loaded. Please upload data first.")
        
        elif prediction_option == "Upload new data":
            uploaded_file = st.file_uploader("Choose a CSV file for prediction", type="csv")
            if uploaded_file:
                prediction_data = pd.read_csv(uploaded_file)
                st.success(f"Prediction data loaded! {prediction_data.shape[0]} rows.")
        
        if prediction_data is not None:
            if st.button("Make Predictions"):
                with st.spinner("Making predictions..."):
                    results = predict_traffic(prediction_data, st.session_state.model, st.session_state.scaler)
                    
                    if results is not None:
                        st.session_state.predictions = results
                        st.success("Predictions completed!")
                        
                        prediction_counts = results['prediction'].value_counts()
                        
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write("Prediction Counts:")
                            st.dataframe(prediction_counts)
                        
                        with col2:
                            st.write("Prediction Distribution:")
                            fig, ax = plt.subplots()
                            sns.countplot(data=results, x='prediction', ax=ax)
                            st.pyplot(fig)
                        
                        st.subheader("Prediction Results Preview")
                        st.dataframe(results.head(10))
                        
                        # Download link
                        st.markdown(get_download_link(results, "predictions.csv", "📥 Download Predictions CSV"), unsafe_allow_html=True)

elif page == "View Results":
    st.header("📊 Results Visualization")
    
    if st.session_state.predictions is None:
        st.warning("No predictions available. Please make predictions first.")
    else:
        results = st.session_state.predictions
        
        st.subheader("Prediction Overview")
        
        tab1, tab2, tab3 = st.tabs(["Summary", "Detailed Analysis", "Raw Data"])
        
        with tab1:
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("Prediction Distribution:")
                fig, ax = plt.subplots(figsize=(8, 6))
                sns.countplot(data=results, x='prediction', ax=ax)
                plt.title("Prediction Distribution")
                plt.xticks(rotation=45)
                st.pyplot(fig)
            
            with col2:
                st.write("Key Metrics:")
                total_connections = len(results)
                st.metric("Total Connections", total_connections)
                
                if 'prediction' in results.columns:
                    # Try to find malicious connections - adapt to whatever values your model predicts
                    try:
                        malicious = results[results['prediction'].str.contains('malicious', case=False)].shape[0]
                        st.metric("Malicious Connections", malicious)
                        st.metric("Malicious Percentage", f"{malicious/total_connections*100:.2f}%")
                    except:
                        # If string comparison fails, just show counts
                        pass
        
        with tab2:
            st.write("Detailed Analysis")
            
            if 'src_ip' in results.columns:
                st.write("Top Source IPs:")
                top_sources = results['src_ip'].value_counts().head(10)
                st.bar_chart(top_sources)
            
            if 'protocol' in results.columns:
                st.write("Protocol Distribution:")
                fig, ax = plt.subplots()
                sns.countplot(data=results, x='protocol', order=results['protocol'].value_counts().index, ax=ax)
                plt.xticks(rotation=45)
                st.pyplot(fig)
            
            if 'src_port' in results.columns and 'dest_port' in results.columns:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("Top Source Ports:")
                    top_src_ports = results['src_port'].value_counts().head(10)
                    st.bar_chart(top_src_ports)
                
                with col2:
                    st.write("Top Destination Ports:")
                    top_dest_ports = results['dest_port'].value_counts().head(10)
                    st.bar_chart(top_dest_ports)
        
        with tab3:
            st.write("Raw Data")
            st.dataframe(results)
            st.markdown(get_download_link(results, "prediction_results.csv", "📥 Download Results CSV"), unsafe_allow_html=True) 